var puppies = (localStorage.getItem('puppies') == null) ? [] : $.parseJSON(localStorage.getItem('puppies'));

 $(document).ready(function(){
    $('.modal').modal();
  });

for (var i = 0; i < puppies.length; i++) {
    if(puppies[i].spec == true){
    $('#featDogs').append(
        '<div class="card" style="height: 25%; width: 25%; display: inline; float: left; margin-right: 20px;">' + 
            '<div class="card-image">' +
              '<img src="' + puppies[i].picture + '">' +
              '<span class="card-title">' + puppies[i].name + '</span>' +
            '</div>' +
            '<div class="card-content">' +
              '<p>' + puppies[i].breed + '</p>' +
            '</div>' +
            '<div>' +
            ' <a class="btn grow" href="#modal' + puppies[i].id + '">View</a>' +
            ' <div>' +
            '<div id="modal' + puppies[i].id + '" class="modal">' +
            '<div class="modal-content">' +
            ' <h2>' + puppies[i].name + '</h2>' +
            '<p>' + puppies[i].dec + '</p>' +
            '</div>' +
            '<div class="modal-footer">' +
            ' <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Close</a>' +
            '</div>' +
            '</div></div>'

            
    )
    }
}

var Puppy = (function(){
    var globalId = (puppies.length > 0 ) ? (puppies[puppies.length - 1].id + 1) : 0;

    return function Puppy(name,breed,age,picture,dec, spec){
    this.id = globalId++;
    this.name = name;
    this.breed = breed;
    this.age = age;
    this.picture = picture;
    this.dec = dec
    this.spec = spec;
    }
})();

$(document).on("click", "#alertDog", function(e) {
    var name = $(this).attr("data-name");
    var dog = GetDogByName(name);
    alert(dog.name +
      dog.age  + dog.dec)


 });





function GetDogByName(name) {

    for (var i = 0; i < puppies.length; i++) {
        if (puppies[i].name == name) {
            return puppies[i];
        }
    }
}