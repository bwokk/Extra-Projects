
var puppies = (localStorage.getItem('puppies') == null) ? [] : $.parseJSON(localStorage.getItem('puppies'));

for (var i = 0; i < puppies.length; i++) {
    $('#tableStuff').append(
        '<tr>' +
        '<td>' + puppies[i].name + '</td>' +
        '<td>' + puppies[i].breed + '</td>' +
        '<td>' + puppies[i].age + '</td>' +
        '<td>' + '<img class="tablePic" src="' + puppies[i].picture + '">' + 
        '</td></tr>'

    )
}


var Puppy = (function(){
    var globalId = (puppies.length > 0 ) ? (puppies[puppies.length - 1].id + 1) : 0;

    return function Puppy(name,breed,age,picture,dec, spec){
    this.id = globalId++;
    this.name = name;
    this.breed = breed;
    this.age = age;
    this.picture = picture;
    this.dec = dec
    this.spec = spec;
    }
})();

$(document).on("click", "#btnAddDog", function (e) {
    var newName = $('#txtName').val();
    var newBreed = $('#txtBreed').val();
    var newAge = $('#txtAge').val();
    var newPic = $('#txtPic').val();
    var newDec = $('#txtDec').val();
     if ($('#test1').is(':checked')) {
        spec = true;
    }
    else {
        spec = false;
    };
    $('#txtName').val('');
    $('#txtBreed').val('');
    $('#txtAge').val('');
    $('#txtPic').val('');
    $('#txtDec').val('');
    var currentPuppy = new Puppy(newName,newBreed,newAge,newPic,newDec, spec);
    puppies.push(currentPuppy);

localStorage.setItem("puppies", JSON.stringify(puppies));


$("#tableStuff").append("<tr><td>" + currentPuppy.name + "</td><td>" +
currentPuppy.breed + "</td><td>" + currentPuppy.age + "</td><td>" + '<img class="tablePic" src="' + puppies[i].picture + '">' + "</td></tr>")
});