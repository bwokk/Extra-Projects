var puppies = (localStorage.getItem('puppies') == null) ? [] : $.parseJSON(localStorage.getItem('puppies'));
var totalAge = [];

for (var i = 0; i < puppies.length; i++) {
    $('.adoptCards').append(
        '<h2 class="header">' + puppies[i].name + '</h2>' +
        '<div class="card horizontal">' +
        '<div class="card-image">' +
        '<img src="' + puppies[i].picture + '">' +
        '</div>' +
        '<div class="card-stacked">' +
        '<div class="card-content">' +
        '<p>Breed: ' + puppies[i].breed + '<br>' + ' Age: ' + puppies[i].age + '<br>' + puppies[i].dec + '</p>' +
        '</div>' +
        '<div class="card-action">' +
         '<a id="cartDog" data-name="' + puppies[i].name + '"' + 'class="btn waves-effect waves-orange">Add To Wagon</a>' +
         '</div>' +
        '</div>' +
        '</div>'

    )
}

var Puppy = (function(){
    var globalId = (puppies.length > 0 ) ? (puppies[puppies.length - 1].id + 1) : 0;

    return function Puppy(name,breed,age,picture, spec){
    this.id = globalId++;
    this.name = name;
    this.breed = breed;
    this.age = age;
    this.picture = picture;
    this.spec = spec;
    }
})();

$(document).on("click", "#cartDog", function (e) {

console.log("click");
    var name = $(this).attr("data-name");
    var dog = GetDogByName(name);
    var ages = 0;
    totalAge.push(dog.age);


    $("#cartDogs").append('<tr><td>' + dog.name + "</td><td>" +
                         dog.age + "</td><td>" + '<i class="material-icons delete" data-name="' + dog.name + '">delete</i>' + "</td></tr>")


    for(var i = 0; i < totalAge.length; i++){
        
        var ages = ages*1 + totalAge[i]*1;
    }
    $("#total").html("Total Age: " + ages)

});

function GetDogByName(name) {

    for (var i = 0; i < puppies.length; i++) {
        if (puppies[i].name == name) {
            return puppies[i];
        }
    }
}

$(document).on("click", ".material-icons", function(e){
    $(this).parent().parent().remove();
    var ages= 0;

    var name = $(this).attr("data-name");
    var dog = GetDogByName(name);

    for(var i = 0; i <totalAge.length; i++){
        var ages = ages*1 + totalAge[i]*1
    }
    var ages = ages*1 - dog.age*1;
    $('#total').html("Total Age: " + ages);
    totalAge.splice(dog.id, 1);


});

