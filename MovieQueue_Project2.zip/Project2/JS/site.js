var movies = [];
var moviesActive = [];
var ratings = [];

var Movie = (function () {

    var globalId = 0;

    return function Movie(name) {
        this.id = globalId++ ,
            this.name = name,
            this.year = Math.floor((Math.random() * (2017-1940)) + 1940),
            this.rating = Math.floor((Math.random() * 10) + 1)
    }

})();
$("#1, #2").sortable({
    connectWith: ".connectedSortable",
    stop: function () {
        var a = Math.floor((Math.random() * 250) + 1);
        var b = Math.floor((Math.random() * 250) + 1);
        var c = Math.floor((Math.random() * 250) + 1);

        $("li").css("background-color", 'rgb(' + a + "," + b + "," + c + ')');
    }
}).disableSelection();


$("#txtAdd").on("keyup", function (e) {
    if (e.keyCode == 13) {
        var newMovie = $("#txtAdd").val();
        var currentMovie = new Movie(newMovie);
        movies.push(currentMovie);



        $("#1").append('<li data-id="' + currentMovie.id + '">' + currentMovie.name + "<div class='rating'>Rating:" + currentMovie.rating + '/10</div></li>');
        $(this).val("");
        InitMovie();

    }
})

$("#txtRemove").on("keyup", function (e) {
    if (e.keyCode == 13) {
        for (var p = 0; p < movies.length; p++) {
            if (movies[p].name == $("#txtRemove").val()) {
                movies.splice(p, 1);
                $("li").eq(p).remove();
                $(this).val("");

            }
        }
        for (var p = 0; p < moviesActive.length; p++) {
            if (moviesActive[p].name == $("#txtRemove").val()) {
                moviesActive.splice(p, 1);
                $('li').eq(p).remove();
                $(this).val("");

            }
        }

    }
});

$(document).on("click", "li", function(e){

 var id = $(this).attr('data-id');
 var movie = GetMovieById(id);

 $('#tblMovie').html("<tr><td>" + movie.name + "</td><td>" 
 + movie.year + "</td><td>" + movie.rating + "/10</tr>");



})

$(document).on("click", ".btn", function (e) {

    console.log("click");
    var total = 0;
    for (var i = 0; i < moviesActive.length; i++) {
        total += moviesActive[i].rating;
    }
    var avg = total / moviesActive.length;
    console.log(avg);

    $('#Average').html(avg);


});

function GetMovieById(id) {

    for (var i = 0; i < movies.length; i++) {
        if (movies[i].id == id) {
            return movies[i];
        }
    };

    for (var i = 0; i < moviesActive.length; i++) {
        if (moviesActive[i].id == id) {
            return moviesActive[i];
        }
    }
}

function InitMovie() {

    $("li").draggable({
        connectToSortable: "#1,#2",
        revert: false,
        stop: function () {
            var parentId = $(this).parent().attr('id');

            if (parentId == '1') {
                var id = $(this).attr('data-id');
                var movie = GetMovieById(id);
                moviesActive.splice(movie.id, 1);
                
            }


            if (parentId == '2') {
                var id = $(this).attr('data-id');
                var movie = GetMovieById(id);
                moviesActive.push(movie);
               
            }


            console.log(moviesActive);



        }
    })

}